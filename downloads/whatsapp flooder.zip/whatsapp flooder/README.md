# Whatsapp-Flooder
### A web.whatsapp.com flooder written in JS.
Link: https://chrome.google.com/webstore/detail/whatsapp-bomb/gifobmlikjfiopmddbgcnolkgkbbbiie
